
// Handle purchase functionality (placeholder for actual payment gateway integration)
function handlePurchase() {
    alert("Please complete your purchase. A notification has been sent to the admin.");
    // You would typically trigger a payment gateway here (Stripe, PayPal, etc.)
    sendNotificationToAdmin(); // Example: notify admin that a purchase is initiated
}

// Temporal payment method change
function updatePaymentMethod(paymentMethod) {
    const paymentInfoElement = document.getElementById("payment-info");
    paymentInfoElement.textContent = paymentMethod;
    alert(`Payment method updated to: ${paymentMethod}`);
}

// Notification system for admin when a customer initiates purchase
function sendNotificationToAdmin() {
    // Placeholder for actual notification system (e.g., email, SMS, or push notification)
    console.log("Admin has been notified of the pending purchase.");
    // You could use Firebase, SMTP, or other services to notify the admin in real-time.
}

// Live Chat Integration
let chatOpen = false;

// Toggle live chat visibility
function toggleChat() {
    const chatWindow = document.getElementById("live-chat");
    if (chatOpen) {
        chatWindow.style.display = "none"; // Hide the chat window
        chatOpen = false;
    } else {
        chatWindow.style.display = "block"; // Show the chat window
        chatOpen = true;
    }
}

// Simulating live chat with a simple message function (you'd integrate a third-party chat service)
function sendChatMessage() {
    const messageBox = document.getElementById("chat-message");
    const chatBox = document.getElementById("chat-box");

    if (messageBox.value.trim()) {
        const newMessage = document.createElement("p");
        newMessage.textContent = messageBox.value;
        chatBox.appendChild(newMessage);
        messageBox.value = ""; // Clear the input box
    } else {
        alert("Please type a message before sending.");
    }
}

// Newsletter subscription functionality (simulated - replace with actual backend integration)
function subscribeNewsletter(event) {
    event.preventDefault(); // Prevent form submission
    const emailInput = document.querySelector("#newsletter-form input");

    if (validateEmail(emailInput.value)) {
        alert("Thank you for subscribing to our newsletter!");
        emailInput.value = ""; // Clear the input field
    } else {
        alert("Please enter a valid email address.");
    }
}

// Simple email validation function for the newsletter form
function validateEmail(email) {
    const regex = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    return regex.test(email);
}

// Event listeners for various interactive elements
document.querySelector("#contact-form").addEventListener("submit", (event) => {
    event.preventDefault(); // Prevent form submission to handle in JavaScript
    alert("Your message has been sent!");
});

document.querySelector("#newsletter-form").addEventListener("submit", subscribeNewsletter);

// Simulate an A/B test (e.g., testing different calls-to-action)
function testCTA() {
    const ctaButton = document.querySelector(".cta-button");
    if (Math.random() > 0.5) {
        ctaButton.textContent = "See Available Kittens";
    } else {
        ctaButton.textContent = "Explore Our Packages";
    }
}

// Run A/B test on page load (you can expand this logic for multiple elements)
window.onload = () => {
    testCTA();
};
